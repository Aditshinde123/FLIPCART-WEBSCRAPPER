from django.urls import path
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns= [
    path("",views.home,name="home"),

    path("contact",views.contact,name="Contact us"),
    path("add",views.add,name="add"),
    path("Manual",views.Manual,name="User-Guide")

]
urlpatterns += staticfiles_urlpatterns()