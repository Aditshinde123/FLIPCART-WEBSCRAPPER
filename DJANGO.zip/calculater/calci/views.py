from django.shortcuts import render
from django.http import HttpResponse
import requests
from bs4 import BeautifulSoup
import pandas as pd


def home(request):
    return render(request, 'home.html',{'gname':'ADIT SHINDE '})


def add(request):
    x=str(request.GET['NUM1'])
    #y=int(request.GET['NUM2'])
    fe= []
    for naga in range(1,3):
        try:
            html = requests.get(x + str(naga))
            soup = BeautifulSoup(html.text, "lxml")
            results = soup.find_all("div", class_="_3pLy-c row")
            n = []
            p = []
            c = []
            c1 =[]
            r =[]
            r1=[]
            k=[]
            k1=[]

            ring = soup.find_all("a")
            for l in ring:

                if len("https://www.flipkart.com" + l.get('href')) > 300:
                    c.append("https://www.flipkart.com" + l.get('href'))
                    c1.append("https://www.flipkart.com" + l.get('href'))

                    ht = requests.get("https://www.flipkart.com" + l.get('href'))
                    sou = BeautifulSoup(ht.text, "lxml")
                    res = sou.find_all("div", class_="_1RLviY")
                    for f in res:
                        r.append(f.text[:-3])
                        r1.append(f.text[:-3])

                        k.append(f.text[-3:])
                        k1.append(f.text[-3:])



                        # if f.text:
                        #     r.append(f.text[:-3])
                        #     k.append(f.text[-3:])
                        # else:
                        #     r.append("none")
                        #     k.append("none")


            for i in results:
                prod = i.find("div", class_="_4rR01T")
                price = i.find("div", class_="_30jeq3 _1_WHN1")

                n.append(prod.text)
                p.append(price.text)


            ping = []
            ping2 = []
            ping3 = []

            if len(c) > 24:

                for z in range(0, 24):
                    ping3.append(c1[z])
            elif len(c) == 24:
                for z in range(0, 24):
                    ping3.append(c1[z])

            elif len(c) < 24:
                for gf in c:
                    ping3.append(gf)
                gk = 24 - len(c)
                for x in range(gk):
                    ping3.append("null")




            if len(r) > 24:

                for z in range(0, 24):
                    ping.append(r1[z])
            elif len(r) == 24:
                for z in range(0, 24):
                    ping.append(r1[z])

            elif len(r) < 24:
                for gf in r:
                    ping.append(gf)
                gk = 24 - len(r)
                for x in range(gk):
                    ping.append("null")

            if len(k) > 24:

                for z in range(0, 24):
                    ping2.append(k1[z])
            elif len(k) == 24:
                for z in range(0, 24):
                    ping2.append(k1[z])

            elif len(k) < 24:
                for gf in k:
                    ping2.append(gf)
                gk = 24 - len(k)
                for x in range(gk):
                    ping2.append("null")

            dictt = {"NAME": n,"PRICE": p,"URL":ping3,"Seller Name":ping,"Seller rating":ping2}
            fe.append(dictt)

        except :
            pass



    tig = pd.DataFrame()
    for rat in fe:
        ui = pd.DataFrame(rat)
        tig = pd.concat([tig, ui])
    print(tig)



    return HttpResponse(tig.sort_values(by="NAME").reset_index(drop=True).to_html())



def contact(request):
    return render(request,'c1.html')

def Manual(request):
    return render(request,"Guide.html")


